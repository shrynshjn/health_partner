
import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt.guard';
import { DailySummaryService } from './daily-summary.service';
import { GetSummaryDto } from './dto/get-summary.dto';
import { CurrentUser } from '../auth/current-user.decorator';

@ApiTags('Daily Summary')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('daily-summary')
export class DailySummaryController {
  constructor(private readonly service: DailySummaryService) {}

  @Get()
  async getSummary(@CurrentUser() user, @Query() query: GetSummaryDto) {
    return this.service.getSummary(user.sub, query.start, query.end);
  }
}
